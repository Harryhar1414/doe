from PIL import Image
image = Image.open('admin.png')
new_image = image.resize((400, 400))
new_image.save('image_400.png')

print(image.size) # Output: (1200, 776)
print(new_image.size) # Output: (400, 400)



image = Image.open('admin.png')
image.thumbnail((400, 400))
image.save('admin.png')

print(image.size) # Output: (400, 258)