from django.contrib import messages
from django.shortcuts import render, redirect

from .forms import SelectForm, CreateSchoolForm
from .models import SchoolInfo, Post, Principal


# Create your views here.
def index(request):
    return render(request, 'frontend/pages/home/home.html')


def register(request):
    data = {
        'schoolData': SchoolInfo.objects.all()
    }
    return render(request, 'frontend/pages/register/register.html', data)


def createpost(request):
    if request.method == 'POST':
        if request.POST.get('title') and request.POST.get('content'):
            post = Post()
            post.title = request.POST.get('title')
            post.content = request.POST.get('content')
            post.save()
            return render(request, 'backend/pages/admin/principal/create.html')
        else:
            return render(request, 'backend/pages/admin/principal/create.html')
    else:
        return render(request, 'backend/pages/admin/principal/create.html')


def login(request):
    return render(request, 'frontend/pages/login/login.html')


def dashboard(request):
    return render(request, 'backend/dashboard.html')


def createschool(request):
    if request.method == 'POST':
        sn = request.POST.get('sname')
        sc = request.POST.get('scode')
        sl = request.POST.get('slogo')
        sreg = request.POST.get('schoolreg')
        scat = request.POST.get('schoolcat')
        sadd = request.POST.get('address')
        sdate = request.POST.get('sestablished')
        sem = request.POST.get('semail')
        scon = request.POST.get('scontact')
        pn = request.POST.get('sprincipal')
        pcon = request.POST.get('s2contact')
        cname = request.POST.get('chairname')
        ccon = request.POST.get('chaircontact')
        ssnum = request.POST.get('ssnumber')
        tnum = request.POST.get('stnumber')
        otnum = request.POST.get('otherstaff')
        simg = request.POST.get('schoolimage')
        lab = request.POST.get('labavailability')
        slab = request.POST.get('sciencelabavailability')
        game = request.POST.get('othergame')
        desc = request.POST.get('description')
        if sn and sc and sl and sreg and scat and sadd and sdate and sem and scon and pn and pcon and cname and ccon and ssnum and tnum and otnum and simg and lab and slab and game and desc:
            p = SchoolInfo()
            p.created_at = sdate
            p.name = sn
            p.code = sc
            p.logo = sl
            p.registrationid = sreg
            p.category = scat
            p.address = sadd
            p.established = sdate
            p.email = sem
            p.contact = scon
            p.principalname = pn
            p.principalcontact = pcon
            p.chairperson = cname
            p.chaircontact = ccon
            p.numofstudent = ssnum
            p.numofteacher = tnum
            p.numofotherstaff = otnum
            p.image = simg
            p.computerlab = lab
            p.sciencelab = slab
            p.ground = game
            p.status = 0
            p.description = desc
            # schooldata = p.objects.all()
            # n = schooldata.serialnum
            # p.serialnum = n + 1
            p.save()
            data = {
                'form': CreateSchoolForm()
            }
            back = request.META['HTTP_REFERER']
            messages.success(request, "School Creation Successfully")
            return redirect(back, data)

        # messages.success(request, 'School Creation Successfully')
        # return render(request, 'backend/pages/admin/createschool.html')
        else:
            data = {
                'form': CreateSchoolForm()
            }
            back = request.META['HTTP_REFERER']
            messages.success(request, "Validation Error")
            return redirect(back, data)

    else:
        data = {
            'form': CreateSchoolForm()
        }
        return render(request, 'backend/pages/admin/school/createschool.html', data)


def schools(request):
    data = {
        'schoolData': SchoolInfo.objects.all()
    }
    return render(request, 'backend/pages/admin/school/schools.html', data)


def schooldetails(request, criteria):
    data = {
        'sc': SchoolInfo.objects.get(code=criteria),
    }
    return render(request, 'backend/pages/admin/school/school_view.html', data)


def ledgerclass1(request):
    return render(request, 'backend/pages/ledger/class1/ledger_view.html')


def addstudent(request):
    return render(request, 'backend/pages/ledger/class1/addstudent.html')


def ledgerschoolwise(request):
    return render(request, 'backend/pages/ledger/schoolwise/ledgerallschool.html')


def gradesheet(request):
    return render(request, 'backend/pages/ledger/gradesheet.html')


def classcollection(request):
    return render(request, 'backend/pages/class/classes.html')


def classdetails(request):
    return render(request, 'backend/pages/class/class.html')


def createclass(request):
    return render(request, 'backend/pages/class/createclass.html')


def principalview(request):
    if request.method == 'POST':
        sl = request.POST.get('selectschool')
        teach = request.POST.get('teachname')
        nep = request.POST.get('tfullname')
        timg = request.POST.get('timage')
        tdob = request.POST.get('tdob')
        citinzennum = request.POST.get('tctzno')
        issuedistrict = request.POST.get('tctzissuedistrict')
        ctzfile = request.POST.get('tctz')
        linnum = request.POST.get('ptln')
        lincat = request.POST.get('tealincat')
        filetlin = request.POST.get('tealin')
        tcat = request.POST.get('catoftech')
        exteach = request.POST.get('texyear')
        exschool = request.POST.get('expeSchool')
        fileex = request.POST.get('exletter')
        maadd = request.POST.get('mailtaddress')
        peradd = request.POST.get('permanentaddress')
        tmob = request.POST.get('tmobnum')
        tmob2 = request.POST.get('tmobnum2')
        mail = request.POST.get('temail')
        bank = request.POST.get('bankname')
        bankacc = request.POST.get('taccnum')
        relname = request.POST.get('rname')
        rmo = request.POST.get('rmob')
        rctz = request.POST.get('rctznum')
        uid = request.POST.get('tuname')
        passw = request.POST.get('tpassword')
        repass = request.POST.get('trepassword')
        if passw == repass:
            t = Principal()
            rec = SchoolInfo.objects.get(code=request.POST.get('selectschool'))
            t.schoolcode = rec
            t.serialnumofprincipal = 2
            t.name = teach
            t.nameinnepali = nep
            t.image = timg
            t.dob = tdob
            t.citizennum = citinzennum
            t.citizenissue = issuedistrict
            t.scancitizenship = ctzfile
            t.licensenum = linnum
            t.categoryoflicense = lincat
            t.license = filetlin
            t.teachercategory = tcat
            t.experienceyear = exteach
            t.experschoolname = exschool
            t.experletter = fileex
            t.mailaddress = maadd
            t.permanentaddress = peradd
            t.mob1 = tmob
            t.mob2 = tmob2
            t.email = mail
            t.bankname = bank
            t.accountnum = bankacc
            t.relationalname = relname
            t.relationalmob = rmo
            t.retionalctzn = rctz
            t.username = uid
            t.password = passw
            t.save()
            back = request.META['HTTP_REFERER']
            messages.success(request, "Principal Creation Successfully")
            data = {
                'form': SelectForm(),
                'schoolData': SchoolInfo.objects.all(),
                'pData': Principal.objects.all()
            }
            return redirect(back, data)
        else:
            back = request.META['HTTP_REFERER']
            messages.success(request, "Please Enter Same Password in Both Field!!")
            data = {
                'form': SelectForm(),
                'schoolData': SchoolInfo.objects.all(),
                'pData': Principal.objects.all()
            }
            return redirect(back, data)

    else:
        data = {
            'form': SelectForm(),
            'schoolData': SchoolInfo.objects.all(),
            'pData': Principal.objects.all()
        }
        return render(request, 'backend/pages/admin/principal/principalview.html', data)


def principaldetails(request, criteria):
    data = {
        'pr': Principal.objects.get(id=criteria),
    }
    return render(request, 'backend/pages/admin/principal/principaldetailsview.html', data)


def teacherview(request):
    data = {
        'sch': SchoolInfo.objects.all(),
        'pData': Principal.objects.all()
    }
    return render(request, 'backend/pages/teacher/teacherview.html',data)


def studentview(request):
    return render(request, 'backend/pages/student/studentview.html')
