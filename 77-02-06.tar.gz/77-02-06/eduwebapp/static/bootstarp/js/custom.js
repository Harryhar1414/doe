$(document).ready(function () {

    $(function () {

        $(document).on('scroll', function () {

            if ($(window).scrollTop() > 100) {
                $('.scroll-top-wrapper').addClass('show');
            } else {
                $('.scroll-top-wrapper').removeClass('show');
            }
        });

        $('.scroll-top-wrapper').on('click', scrollToTop);
    });

    function scrollToTop() {
        verticalOffset = typeof(verticalOffset) != 'undefined' ? verticalOffset : 0;
        element = $('body');
        offset = element.offset();
        offsetTop = offset.top;
        $('html, body').animate({scrollTop: offsetTop}, 500, 'linear');
    }

});


var btnContainer = document.getElementById("topHeader");

// Get all buttons with class="btn" inside the container
var btns = btnContainer.getElementsByClassName("nav-item");

// Loop through the buttons and add the active class to the current/clicked button
for (var i = 0; i < btns.length; i++) {
    btns[i].addEventListener("click", function () {
        var current = document.getElementsByClassName("active");
        current[0].className = current[0].className.replace(" active", "");
        this.className += " active";
    });
}


jQuery.fn.liScroll = function (settings) {
    settings = jQuery.extend({
        travelocity: 0.01
    }, settings);
    return this.each(function () {
        var $strip = jQuery(this);
        $strip.addClass("newsticker")
        var stripHeight = 1;
        $strip.find("li").each(function (i) {
            stripHeight += jQuery(this, i).outerHeight(true); // thanks to Michael Haszprunar and Fabien Volpi
        });
        var $mask = $strip.wrap("<div class='mask'></div>");
        var $tickercontainer = $strip.parent().wrap("<div class='tickercontainer'></div>");
        var containerHeight = $strip.parent().parent().height();	//a.k.a. 'mask' width
        $strip.height(stripHeight);
        var totalTravel = stripHeight;
        var defTiming = totalTravel / settings.travelocity;	// thanks to Scott Waye
        function scrollnews(spazio, tempo) {
            $strip.animate({top: '-=' + spazio}, tempo, "linear", function () {
                $strip.css("top", containerHeight);
                scrollnews(totalTravel, defTiming);
            });
        }

        scrollnews(totalTravel, defTiming);
        $strip.hover(function () {
                jQuery(this).stop();
            },
            function () {
                var offset = jQuery(this).offset();
                var residualSpace = offset.top + stripHeight;
                var residualTime = residualSpace / settings.travelocity;
                scrollnews(residualSpace, residualTime);
            });
    });
};

$(function () {
    $("ul#ticker01").liScroll();
});


$('#roll').on('click', function () {
    $("#roll option").filter(function () {
        return $(this).val() == "choose";
    }).prop('selected', true);

    // On change will always fire
    $('#roll').on('change', Changing);
});

function Changing() {
    let currentValue = $('#roll').val();
    if (currentValue == 'teacher') {
        $('#reg_form').modal('show');
        //document.getElementById("reg_form").style.display = "block";
        document.getElementById("reg_form2").style.display = "none";
        document.getElementById("reg_form1").style.display = "none";
    }
    else if (currentValue == 'admin') {
        //document.getElementById("reg_form").innerHTML = ('<h1>You are at Registration as Admin</h1>' );
        $('#reg_form1').modal('show');
        // document.getElementById("reg_form1").style.display = "block";
        document.getElementById("reg_form2").style.display = "none";
        document.getElementById("reg_form").style.display = "none";
    }
    else {
        $('#reg_form2').modal('show');
        // document.getElementById("reg_form2").style.display = "block";
        document.getElementById("reg_form1").style.display = "none";
        document.getElementById("reg_form").style.display = "none";
        //document.getElementById("reg_form").innerHTML = ('<h1> You are at Registration as Student</h1>' );
    }
}

function selschool(){
    $('#selstudent').modal('show');
}
function logIn() {
    window.open("../NewProject/index.html");
}

function myFunction() {
   var x=document.getElementById("schoolcodeselection").value;
    document.getElementById("schlcode").innerHTML = x;
   var sel = document.getElementById("schoolcodeselection");
   var y=sel.options[sel.selectedIndex].text;
   document.getElementById('teacherName').value=y;
}
