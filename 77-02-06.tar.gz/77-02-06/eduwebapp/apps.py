from django.apps import AppConfig


class EduwebappConfig(AppConfig):
    name = 'eduwebapp'
