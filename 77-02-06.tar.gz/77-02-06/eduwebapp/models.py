from django.db import models


# Create your models here.


class SchoolInfo(models.Model):
    created_at = models.DateField()
    name = models.CharField(max_length=150, unique=True)
    code = models.CharField(max_length=20, unique=True)
    logo = models.ImageField(upload_to='backend/image/school/logo/')
    registrationid = models.CharField(max_length=40, unique=True)
    category = models.CharField(max_length=40)
    address = models.CharField(max_length=60)
    established = models.DateField()
    email = models.EmailField()
    contact = models.CharField(max_length=15)
    principalname = models.CharField(max_length=40)
    principalcontact = models.CharField(max_length=14)
    chairperson = models.CharField(max_length=40)
    chaircontact = models.CharField(max_length=14)
    numofstudent = models.IntegerField()
    numofteacher = models.IntegerField()
    numofotherstaff = models.IntegerField()
    image = models.ImageField(upload_to='backend/image/school/image/')
    computerlab = models.BooleanField(default=0)
    sciencelab = models.BooleanField(default=0)
    ground = models.CharField(max_length=200)
    status = models.BooleanField(default=0)
    description = models.TextField()

    def __str__(self):
        return str(self.code)


class Principal(models.Model):
    serialnumofprincipal = models.PositiveIntegerField()
    schoolcode = models.ForeignKey(SchoolInfo, on_delete=models.CASCADE)
    name = models.CharField(max_length=40, blank=True, null=True)
    nameinnepali = models.CharField(max_length=40)
    image = models.ImageField(upload_to='backend/image/principal/')
    dob = models.DateField()
    citizennum = models.CharField(max_length=40)
    citizenissue = models.CharField(max_length=40)
    scancitizenship = models.ImageField(upload_to='backend/image/principal/citizenship/')
    licensenum = models.CharField(max_length=30, blank=True)
    categoryoflicense = models.CharField(max_length=30, blank=True)
    license = models.ImageField(upload_to='backend/image/principal/license/')
    teachercategory = models.CharField(max_length=30)
    experienceyear = models.CharField(max_length=3, blank=True)
    experschoolname = models.CharField(max_length=40, blank=True)
    experletter = models.ImageField(upload_to='backend/image/principal/experience/', blank=True)
    mailaddress = models.CharField(max_length=50)
    permanentaddress = models.CharField(max_length=50)
    mob1 = models.CharField(max_length=15)
    mob2 = models.CharField(max_length=15, blank=True)
    email = models.EmailField(blank=True)
    bankname = models.CharField(max_length=50, blank=True)
    accountnum = models.CharField(max_length=40, blank=True)
    relationalname = models.CharField(max_length=40, blank=True)
    relationalmob = models.CharField(max_length=15, blank=True)
    retionalctzn = models.CharField(max_length=40, blank=True)
    status = models.BooleanField(default=0)
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)

    def __str__(self):
        return str(self.name)


class Post(models.Model):
    title = models.CharField(max_length=70, unique=True)
    content = models.TextField()

    def __str__(self):
        return self.title
