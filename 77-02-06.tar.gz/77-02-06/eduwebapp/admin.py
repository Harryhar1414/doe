from django.contrib import admin
from .models import SchoolInfo, Post, Principal


# Register your models here.
@admin.register(SchoolInfo)
class AdminSchoolDetails(admin.ModelAdmin):
    list_display = ['name', 'code', 'contact', 'principalname', 'principalcontact', 'status']
    list_per_page = 7
    search_fields = ['name', 'code', 'created_at']
    date_hierarchy = 'created_at'


@admin.register(Principal)
class AdminPrincipalDetails(admin.ModelAdmin):
    list_display = ['schoolcode', 'name', 'citizennum', 'mob1', 'email']
    list_per_page = 7
    search_fields = ['name', 'schoolcode', 'citizennum']


@admin.register(Post)
class AdminPostDetails(admin.ModelAdmin):
    list_display = ['title', 'content']
