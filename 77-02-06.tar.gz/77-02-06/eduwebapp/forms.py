from django import forms

from .models import SchoolInfo, Principal


class SelectForm(forms.ModelForm):
    class Meta:
        model = Principal
        fields = ('schoolcode', 'name')


class CreateSchoolForm(forms.ModelForm):
    class Meta:
        model = SchoolInfo
        fields = ('name', 'code', 'logo', 'registrationid', 'category', 'address', 'established', 'email',
                  'contact', 'principalname', 'principalcontact', 'chairperson', 'chaircontact', 'numofstudent',
                  'numofteacher', 'numofotherstaff', 'image', 'computerlab', 'sciencelab', 'ground', 'description')
        labels = {
            'registrationid': 'Registration'
        }