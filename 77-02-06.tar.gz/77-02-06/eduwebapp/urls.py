from django.urls import path

from . import views

urlpatterns = [
    path('', views.index),
    path('register', views.register, name='register'),
    path('login', views.login, name='login'),
    path('dashboard', views.dashboard, name='dashboard'),
    path('schools', views.schools, name='schools'),
    path('createschool', views.createschool, name='createschool'),
    path('schooldetailsview/<slug:criteria>', views.schooldetails, name='schoolview'),
    path('classes', views.classcollection, name="classes"),
    path('schoolwiseclasses', views.classdetails, name='classwise'),
    path('principalview', views.principalview, name='principaldetails'),
    path('principaldetailsview/<slug:criteria>', views.principaldetails, name='principaldetails'),
    path('teacherview', views.teacherview, name='teacherdetails'),
    path('studentview', views.studentview, name='studentview'),
    path('createclass', views.createclass, name='addclass'),
    path('addstudent', views.addstudent, name='addstudentinledger'),
    path('ledgerclass1', views.ledgerclass1, name='ledgerClassOne'),
    path('ledgerschoolwise', views.ledgerschoolwise, name='ledgerschoolwise'),
    path('gradesheet', views.gradesheet, name='gradesheet'),
    path('create', views.createpost, name='create')
]
